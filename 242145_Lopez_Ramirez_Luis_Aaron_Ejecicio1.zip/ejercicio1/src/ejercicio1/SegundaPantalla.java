package ejercicio1;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.imageio.ImageIO;

public class SegundaPantalla extends JPanel implements ActionListener {

    Font fuente = new Font("URW Gothic", Font.PLAIN, 18);
    String url;
    String usuario;
    String contraseña;
    String Sbase;
    BufferedImage fondo;
    JLabel labelSelectedBase;
    JComboBox<String> comboBox;
    JButton selectButton;
    ResultSet resultSet;
    JFrame jf;
    JTextArea textArea;
    JScrollPane scrollPane;

    public SegundaPantalla(JFrame jf, String url, String usuario, String contraseña, String Sbase, ResultSet resultSet) {
        this.jf = jf;
        this.url = url;
        this.contraseña = contraseña;
        this.usuario = usuario;
        this.Sbase = Sbase;
        this.resultSet = resultSet;
        setPreferredSize(new Dimension(800, 600));
        conectar();
        cargarImagenes();

        setLayout(null);

        labelSelectedBase = new JLabel("Seleccione la tabla con la que quiera trabajar:");
        labelSelectedBase.setBounds(50, 20, 500, 30);
        labelSelectedBase.setFont(fuente);
        add(labelSelectedBase);

        comboBox = new JComboBox<String>();
        try {
            while (resultSet.next()) {
                String tableName = resultSet.getString("TABLE_NAME");
                comboBox.addItem(tableName);
            }
        } catch (SQLException ex) {
            Logger.getLogger(SegundaPantalla.class.getName()).log(Level.SEVERE, null, ex);
        }
        comboBox.setBounds(50, 60, 500, 40);
        add(comboBox);

        selectButton = new JButton("Seleccionar");
        selectButton.setBounds(250, 120, 100, 40);
        selectButton.addActionListener(this);
        add(selectButton);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(fuente);
        scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(50, 180, 700, 500);
        scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane);
    }

    public void conectar() {
        try {
            Connection connection = DriverManager.getConnection(url, usuario, contraseña);
            if (connection != null) {
                Statement statement = connection.createStatement();
                String useDatabaseQuery = "USE " + Sbase;
                statement.executeUpdate(useDatabaseQuery);
                statement.close();
                connection.close();
            } else {
                System.out.println("Error al conectar con la base de datos");
            }
        } catch (SQLException ex) {
            System.out.println("Error al conectar con la base de datos: " + ex.getMessage());
        }
        repaint();
    }

    public void seleccionarTabla(String selectedTable) {
        try {
            Connection connection = DriverManager.getConnection(url, usuario, contraseña);
            Statement statement = connection.createStatement();

            // Seleccionar la base de datos
            String useDatabaseQuery = "USE " + Sbase;
            statement.executeUpdate(useDatabaseQuery);

            String query = "DESCRIBE " + selectedTable;
            ResultSet resultSet = statement.executeQuery(query);

            StringBuilder description = new StringBuilder();
            description.append("+-------------+-------------+------+-----+---------+----------------+\n");
            description.append("| Field       | Type        | Null | Key | Default | Extra          |\n");
            description.append("+-------------+-------------+------+-----+---------+----------------+\n");
            while (resultSet.next()) {
                String fieldName = resultSet.getString("Field");
                String fieldType = resultSet.getString("Type");
                String fieldNull = resultSet.getString("Null");
                String fieldKey = resultSet.getString("Key");
                String fieldDefault = resultSet.getString("Default");
                String fieldExtra = resultSet.getString("Extra");

                String fieldDescription = String.format("| %-12s | %-11s | %-4s | %-3s | %-7s | %-14s |\n",
                        fieldName, fieldType, fieldNull, fieldKey, fieldDefault, fieldExtra);
                description.append(fieldDescription);
            }
            description.append("+-------------+-------------+------+-----+---------+----------------+\n");
            textArea.setText(description.toString());

            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException ex) {
            System.out.println("Error al seleccionar la tabla: " + ex.getMessage());
        }
    }

    public void cargarImagenes() {
        try {
            fondo = ImageIO.read(getClass().getResource("/ejercicio1/fondo.jpg"));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == selectButton) {
            String selectedTable = (String) comboBox.getSelectedItem();
            System.out.println(selectedTable);
            seleccionarTabla(selectedTable);
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;

        g2.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
    }
}
