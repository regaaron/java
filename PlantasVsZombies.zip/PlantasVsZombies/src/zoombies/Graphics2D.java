package zoombies;

public class Graphics2D {

}
